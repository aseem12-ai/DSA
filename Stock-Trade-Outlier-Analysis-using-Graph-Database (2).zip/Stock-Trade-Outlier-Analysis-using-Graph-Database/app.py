import streamlit as st
import pandas as pd
from data_loader import load_and_clean_data, detect_outliers
from analysis import compute_guideline_deviation
from visualization import plot_boxplot, plot_guideline_scatter, view_graph, Chart

# Sidebar Navigation
st.sidebar.title("Navigation")
selected_section = st.sidebar.radio(
    "Choose Section", ["Dataset Overview", "Outlier Analysis", "Network Graphs", "Additional Visualizations"]
)

# Dashboard Title
st.title("Stock Trade Outlier Analysis Dashboard")
st.markdown("---")

# Load and process dataset
csv_path = "assets/EURUSD.csv"
df_raw = pd.read_csv(csv_path)
df_cleaned = compute_guideline_deviation(detect_outliers(load_and_clean_data(csv_path)))

# Dataset Overview
if selected_section == "Dataset Overview":
    st.header("Dataset Details")
    st.markdown(f"**Rows:** {df_raw.shape[0]} | **Columns:** {df_raw.shape[1]}")
    st.write("**Columns:**", df_raw.columns.tolist())
    st.write("**Summary:**", df_raw.describe())

    st.subheader("Raw Data Sample")
    st.write(df_raw.head())

    st.markdown("---")
    st.header("Processed Data Sample")
    st.subheader("After Cleaning & Analysis")
    st.write(df_cleaned.head(20).tail(5))

# Outlier Analysis
elif selected_section == "Outlier Analysis":
    st.header("Outlier Detection & Analysis")
    outlier_count = df_cleaned["is_outlier"].sum()
    st.write(f"**Total Outliers:** {outlier_count}")

    st.subheader("Boxplot: Daily Returns")
    st.pyplot(plot_boxplot(df_cleaned))

    st.markdown("---")
    st.subheader("Scatter Plot: Trade Volume vs Daily Return")
    st.pyplot(plot_guideline_scatter(df_cleaned))

# Network Graphs
elif selected_section == "Network Graphs":
    st.header("Trade Network Graphs")
    
    st.subheader("Graph: 100 Nodes & 156 Relationships")
    st.plotly_chart(view_graph("assets/graph.png", "Trade Network with 100 nodes, 156 relationships"), use_container_width=True)

    st.subheader("Graph: Outlier Nodes Only")
    st.plotly_chart(view_graph("assets/graph2.png", "Trade Network with only outlier nodes"), use_container_width=True)

# Additional Visualizations
elif selected_section == "Additional Visualizations":
    st.header("Trade Data Visualizations")
    chart = Chart(df_cleaned)

    st.subheader("Line Chart: Trade Volume Over Time")
    st.plotly_chart(chart.line_chart(), use_container_width=True)

    st.subheader("Scatter Plot: Close Price Over Time")
    st.plotly_chart(chart.scatter_plot(), use_container_width=True)

    st.subheader("Histogram: Betweenness Centrality")
    st.pyplot(chart.betweeness_centrality())

    st.subheader("Bar Chart: Trade Status Counts")
    st.plotly_chart(chart.bar_chart(), use_container_width=True)

# Summary Report
st.markdown("---")
st.header("Summary Report")

total_trades = len(df_cleaned)
total_outliers = df_cleaned["is_outlier"].sum()
total_deviations = df_cleaned["deviates_guideline"].sum()
total_normal = total_trades - total_outliers - total_deviations

summary_report = f"""
**Trade Summary Report**

- **Total Trades:** {total_trades}
- **Outlier Trades:** {total_outliers}
- **Guideline Deviations:** {total_deviations}
- **Normal Trades:** {total_normal}

**Key Insights:**
- Boxplot highlights daily return distributions and outliers.
- Scatter plot reveals deviations in trade volume vs daily return.
- Network graphs visualize trade relationships and anomalies.
- Additional charts provide deeper insights into trading patterns.
"""
st.markdown(summary_report)
